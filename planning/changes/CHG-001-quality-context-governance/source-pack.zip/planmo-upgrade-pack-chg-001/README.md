# PlanMo Upgrade Pack — CHG-001

This package is an **overlay / rebaseline pack** for an existing PlanMo repository whose Phase 03 is already complete.

Known implementation checkpoint supplied by the project owner:

- Phase 03 complete
- safe filesystem utilities
- managed writer
- `planmo init`
- read-only `planmo status`
- collision/symlink/traversal/malformed-manifest/dry-run/idempotency tests
- full `pnpm check`
- 5 test files / 35 tests
- consistency checks + secret scan
- commit: `ea19fa3 feat(cli): complete phase 03 foundation`
- Phase 03 handoff exists

## Important

**Do not blindly overwrite the current repository.**

This pack contains:
- new documents that can be copied as-is;
- roadmap/task addenda that must be merged into the current tracker;
- ADR proposals;
- engineering, standards, context/memory, change, evaluation, and trust architecture;
- a rebaseline prompt for an AI coding agent.

The current repository and its Phase 03 handoff remain the source of truth.

## Upgrade themes

1. Standards Engine
2. Quality / Maintainability Engine
3. Context & Persistent Memory Engine
4. Repository Context Map
5. Change Engine / delta planning
6. Managed-file ownership + lineage
7. Task graph / claims / execution packets
8. Architecture fitness rules
9. AI planning evals
10. Future pack/release trust architecture

## Recommended application flow

1. Ensure Phase 03 branch is clean and commit `ea19fa3` (or its descendant) exists.
2. Copy this folder into a temporary directory beside the repository.
3. Start a **fresh AI-agent session**.
4. Give the agent `prompts/APPLY-CHG-001.md`.
5. The agent should merge this upgrade into the existing plan **without starting Phase 04 implementation**.
6. Review the rebaseline commit/PR.
7. Start Phase 04 in another fresh session.
