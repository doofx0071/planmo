# ADR-0008 — Context/Memory Authority Model

**Status:** Proposed

Canonical repository/project artifacts outrank memory.

Memory is derived context with provenance and temporal validity. If memory conflicts with current source, schemas, accepted ADRs, requirements, tracker, state, or handoff, the canonical artifact wins.

This prevents persistent memory from becoming an invisible second database of truth.
