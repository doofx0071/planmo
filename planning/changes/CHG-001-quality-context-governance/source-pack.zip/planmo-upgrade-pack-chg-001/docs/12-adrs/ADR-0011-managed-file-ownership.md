# ADR-0011 — Managed File Ownership Classes

**Status:** Proposed

PlanMo-generated files use explicit ownership classes:
- generated
- merged
- seeded
- user

Generation/update behavior must respect ownership and expose diffs before destructive changes.
