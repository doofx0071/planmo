# ADR-0007 — Standards and Quality Engines

**Status:** Proposed

PlanMo will model engineering standards and maintainability checks as first-class concepts.

Standards are selected based on task/stack/domain rather than injecting every rule into every prompt.

Quality findings must be concrete and evidence-backed. Refactoring should be justified by correctness, maintainability, testability, architecture, security, or measurable performance—not stylistic preference alone.
