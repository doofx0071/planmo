# ADR-0012 — Task Graph, Claims, and Execution Packets

**Status:** Proposed

PlanMo tasks become an explicit dependency graph with ready/blocked state.

Parallel-agent work may use claim leases.

Each worker receives a bounded Execution Packet containing requirements, standards, context, risks, ownership, and tests.
