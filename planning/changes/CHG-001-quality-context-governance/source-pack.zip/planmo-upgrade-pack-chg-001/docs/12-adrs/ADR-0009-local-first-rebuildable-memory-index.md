# ADR-0009 — Local-first, Rebuildable Memory/Context Index

**Status:** Proposed

PlanMo's core context/memory capability must work locally without a hosted service.

Derived indexes must be disposable/rebuildable. Semantic embeddings and temporal graph services are optional adapters.

The concrete local storage/search driver will be chosen after cross-platform benchmarking; the architectural contract must not depend on one vendor.
