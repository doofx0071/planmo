# ADR-0010 — First-class Change Packages and Requirement Deltas

**Status:** Proposed

Substantial changes after initial planning are represented as change packages containing explicit ADDED/MODIFIED/REMOVED requirement deltas, impacts, risks, tasks, and tests.

Accepted changes are merged into canonical planning state and archived with provenance.
