# Patch Manifest

## Copy as new files

These paths are intended to be new and may be copied into the PlanMo repository if no path already exists:

- `planning/changes/CHG-001-quality-context-governance/**`
- `docs/13-standards-quality/**`
- `docs/14-context-memory/**`
- `docs/15-change-governance/**`
- `docs/16-evals-trust/**`
- `docs/12-adrs/ADR-0007-standards-and-quality-engine.md`
- `docs/12-adrs/ADR-0008-context-memory-authority-model.md`
- `docs/12-adrs/ADR-0009-local-first-rebuildable-memory-index.md`
- `docs/12-adrs/ADR-0010-change-engine-delta-model.md`
- `docs/12-adrs/ADR-0011-managed-file-ownership.md`
- `docs/12-adrs/ADR-0012-task-graph-and-execution-packets.md`
- `specs/**`

## Merge, do not overwrite

Use these as addenda to existing repository files:

- `planning/phase-addenda/**`
- `prompts/AGENTS-ADDITIONS.md`
- `prompts/ROADMAP-MERGE-NOTES.md`
- `prompts/TRACKER-MERGE-NOTES.md`

## Historical stability

Do not renumber or rewrite completed Phase 00–03 task IDs merely to fit this upgrade.

If a completed Phase 03 capability needs a compatibility improvement, create a new follow-up task and link it to CHG-001.
