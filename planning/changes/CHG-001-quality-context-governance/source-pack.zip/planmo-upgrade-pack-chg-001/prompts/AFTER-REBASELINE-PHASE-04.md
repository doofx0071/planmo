# Start Phase 04 After CHG-001

Use this only after CHG-001 has been merged and its handoff completed.

Read:
1. root `AGENTS.md`
2. CHG-001 rebaseline handoff
3. current Phase 04 prompt/plan
4. accepted CHG-001 ADRs
5. tracker/tasks/risk/traceability
6. current Git state

Implement Phase 04 only, including the accepted Standards Pack / engineering-policy / provenance additions.

Do not implement the actual Context/Memory storage engine prematurely if the rebaselined roadmap assigns it to later phases.

Hard-stop before Phase 05.
