# Roadmap Merge Notes

Do not renumber phases.

Update Phase 04–12 descriptions using `planning/phase-addenda/`.

Add CHG-001 as an accepted/rejected planning change and link it from the roadmap.

If the Phase 03 implementation cannot represent future ownership/lineage, create a new follow-up task under Phase 05 rather than rewriting Phase 03 history.
