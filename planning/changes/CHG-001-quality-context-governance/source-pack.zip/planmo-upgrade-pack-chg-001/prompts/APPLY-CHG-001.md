# Apply CHG-001 Rebaseline

Read the existing repository-root `AGENTS.md` first.

Then read:
- the actual `planning/handoffs/phase-03-handoff.md`;
- current Git history/status;
- roadmap, tracker, tasks, risks, decisions, traceability;
- existing ADRs;
- this upgrade pack's `README.md`, `PATCH-MANIFEST.md`, and `planning/changes/CHG-001-quality-context-governance/**`.

## Known checkpoint

The owner reports Phase 03 is complete at commit:
`ea19fa3 feat(cli): complete phase 03 foundation`

Verify rather than blindly trusting this summary.

## Mission

Rebaseline the PlanMo **planning repository only** to incorporate CHG-001.

Do NOT begin Phase 04 product implementation in this session.

## Merge rules

1. Preserve completed Phase 00–03 task IDs/history.
2. Copy genuinely new docs/ADRs/spec examples into appropriate destinations.
3. Merge phase addenda into future phase plans/prompts.
4. Add requirement families:
   - REQ-STD
   - REQ-QLT
   - REQ-CTX
   - REQ-MEM
   - REQ-CHG
   - REQ-SYN
   - REQ-WRK
   - REQ-ARCH
   - REQ-EVAL
   - REQ-TRUST
5. Add future tasks from CHG-001 to the canonical task tracker with dependencies/acceptance evidence.
6. Update risks, decisions, traceability, master plan and roadmap.
7. Merge the proposed `AGENTS.md` additions instead of replacing current content.
8. Accept/reject each proposed ADR explicitly.
9. Do not introduce a hosted memory/vector/graph dependency as a required v1 component.
10. Keep canonical state authoritative over memory.
11. Add tests/acceptance gates for every new capability.

## Context/Memory design constraints

PlanMo memory must be:
- local-first;
- agent-neutral;
- provenance-bearing;
- temporally valid/supersedable;
- scope-filtered;
- secret-safe;
- token-budgeted;
- rebuildable where derived.

Raw chat transcripts are not durable project memory by default.

The initial retrieval baseline must be deterministic enough to test. Semantic embeddings may be optional adapters later.

## Completion

Before stopping:
- run planning consistency checks available in the repo;
- ensure no duplicate task/requirement IDs;
- ensure future phases own all accepted work;
- create a CHG-001 rebaseline handoff;
- create a focused commit/PR if Git operations are available.

Then STOP before Phase 04.

Do not merely explain the rebaseline. Perform it.
