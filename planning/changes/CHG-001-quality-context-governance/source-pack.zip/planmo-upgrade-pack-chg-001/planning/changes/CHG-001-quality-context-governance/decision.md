# CHG-001 Decision

## Recommended decision
ACCEPT, with staged implementation.

## Architectural decisions

1. Canonical repository state is authoritative; memory is not.
2. PlanMo memory is project-centric and local-first.
3. v1 uses deterministic/rebuildable retrieval as the baseline.
4. Embeddings are optional adapters.
5. Temporal graph memory is a future adapter, not a core dependency.
6. Session handoffs remain Git-tracked durable evidence.
7. Memory stores distilled facts/events/procedures, not raw chat by default.
8. Context compilation uses explicit token/size budgets and progressive disclosure.
9. Every durable memory has provenance and temporal validity.
10. Quality/standards are structured PlanMo concepts, not only prose in AGENTS.md.
