# CHG-001 Rebaseline Acceptance Gates

Before Phase 04 starts:

- [ ] Phase 03 completion remains intact and traceable.
- [ ] No completed Phase 00–03 task ID is renumbered.
- [ ] New REQ-STD/QLT/CTX/MEM/CHG/SYN/WRK/ARCH/EVAL/TRUST families exist.
- [ ] New requirements map to future phase tasks.
- [ ] Memory authority hierarchy is explicit.
- [ ] Local-first v1 memory decision is recorded.
- [ ] Raw chat is not the default durable memory format.
- [ ] Token-budgeted context bundle concept is accepted.
- [ ] Memory poisoning/secrets/staleness risks are in the risk register.
- [ ] Phase 04–12 prompts are updated or have explicit addenda.
- [ ] New ADRs are accepted/rejected explicitly.
- [ ] Rebaseline itself has a handoff and commit/PR.
