# Upgrade Migration Checklist

## Before
- [ ] Phase 03 is committed and clean.
- [ ] `phase-03-handoff.md` exists.
- [ ] `pnpm check` passes.
- [ ] backup/branch/tag exists.

## Rebaseline
- [ ] CHG-001 folder copied.
- [ ] proposed ADRs reviewed.
- [ ] requirement families appended.
- [ ] tasks appended without changing completed IDs.
- [ ] phase addenda merged.
- [ ] AGENTS additions merged.
- [ ] risks/traceability updated.
- [ ] planning consistency validation passes.

## Memory-specific
- [ ] canonical authority hierarchy accepted.
- [ ] local-first baseline accepted.
- [ ] raw chat persistence is opt-in/not default.
- [ ] secret redaction requirement exists.
- [ ] provenance and temporal validity required.
- [ ] context token budgets required.
- [ ] poisoning/staleness eval tasks exist.

## After
- [ ] rebaseline handoff created.
- [ ] rebaseline commit/PR created.
- [ ] next phase remains Phase 04.
- [ ] new fresh session used for Phase 04.
